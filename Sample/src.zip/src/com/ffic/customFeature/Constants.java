package com.ffic.customFeature;

public class Constants
{
	/*public static final int HASH_CODE_ICMClaimsDocument = -1639575739;
	public static final int HASH_CODE_ICMClaimsDocumentNew = 2062295067;
	public static final int HASH_CODE_ICMStandardScannedDocument = -1127641413;
	public static final int HASH_CODE_ICMPersonalDocument = -1445514226;
	//Added for Entertainment
	public static final int HASH_CODE_UnderwritingDocument = -1002862602;
	//End of Entertainment
	//Added For Cube
	public static final String CLASS_NAME="Underwriting_Document";
	//End For Cube
*/	public static final String pluginPropertyEnvVariable ="com.ibm.icn.custom.plugin.jsonFileLocation";
	public static final String edsLog4jPropertyEnvVariable ="com.ibm.icn.custom.eds.log4jPropertyFileLocation";
}
